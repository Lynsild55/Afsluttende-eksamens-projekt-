package fr.hovedopgave.demo.service;

public interface CompanyService {
    
}
