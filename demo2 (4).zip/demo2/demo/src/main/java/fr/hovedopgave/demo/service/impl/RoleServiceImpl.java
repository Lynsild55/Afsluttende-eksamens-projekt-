package fr.hovedopgave.demo.service.impl;

import fr.hovedopgave.demo.service.RoleService;

public class RoleServiceImpl implements RoleService{
    
}
