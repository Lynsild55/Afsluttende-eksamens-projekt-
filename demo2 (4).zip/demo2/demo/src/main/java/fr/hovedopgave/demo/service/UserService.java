package fr.hovedopgave.demo.service;

import fr.hovedopgave.demo.dto.RegisterDTO;

public interface UserService {
        void saveUser(RegisterDTO registrationDto);
}
