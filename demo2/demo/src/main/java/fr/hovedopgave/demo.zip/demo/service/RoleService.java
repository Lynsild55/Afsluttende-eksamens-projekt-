package fr.hovedopgave.demo.service;

public interface RoleService {
    
}
