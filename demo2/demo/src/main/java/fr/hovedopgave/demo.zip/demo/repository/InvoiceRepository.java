package fr.hovedopgave.demo.repository;

public interface InvoiceRepository {
    
}
