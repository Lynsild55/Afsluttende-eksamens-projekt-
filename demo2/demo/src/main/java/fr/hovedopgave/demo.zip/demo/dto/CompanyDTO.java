package fr.hovedopgave.demo.dto;

public class CompanyDTO {
    
}
